﻿namespace FairManagementSystemVer1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.visitorNameLabel = new System.Windows.Forms.Label();
            this.visitorNameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.contactNumberTextBox = new System.Windows.Forms.TextBox();
            this.zoneType1CheckBox = new System.Windows.Forms.CheckBox();
            this.zoneType2CheckBox = new System.Windows.Forms.CheckBox();
            this.zoneType3CheckBox = new System.Windows.Forms.CheckBox();
            this.zoneType4CheckBox = new System.Windows.Forms.CheckBox();
            this.zoneType5CheckBox = new System.Windows.Forms.CheckBox();
            this.zoneType6CheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.contactNumberTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.emailTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.visitorNameTextBox);
            this.groupBox1.Controls.Add(this.visitorNameLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(481, 161);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Visitor\'s Information";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.zoneType6CheckBox);
            this.groupBox2.Controls.Add(this.zoneType5CheckBox);
            this.groupBox2.Controls.Add(this.zoneType4CheckBox);
            this.groupBox2.Controls.Add(this.zoneType3CheckBox);
            this.groupBox2.Controls.Add(this.zoneType2CheckBox);
            this.groupBox2.Controls.Add(this.zoneType1CheckBox);
            this.groupBox2.Location = new System.Drawing.Point(12, 173);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(481, 172);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Zone type visitor\'s want to visit";
            // 
            // visitorNameLabel
            // 
            this.visitorNameLabel.AutoSize = true;
            this.visitorNameLabel.Location = new System.Drawing.Point(31, 23);
            this.visitorNameLabel.Name = "visitorNameLabel";
            this.visitorNameLabel.Size = new System.Drawing.Size(41, 13);
            this.visitorNameLabel.TabIndex = 0;
            this.visitorNameLabel.Text = "Name :";
            // 
            // visitorNameTextBox
            // 
            this.visitorNameTextBox.Location = new System.Drawing.Point(172, 16);
            this.visitorNameTextBox.Name = "visitorNameTextBox";
            this.visitorNameTextBox.Size = new System.Drawing.Size(251, 20);
            this.visitorNameTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Email :";
            // 
            // emailTextBox
            // 
            this.emailTextBox.Location = new System.Drawing.Point(172, 53);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(251, 20);
            this.emailTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Contact number :";
            // 
            // contactNumberTextBox
            // 
            this.contactNumberTextBox.Location = new System.Drawing.Point(172, 96);
            this.contactNumberTextBox.Name = "contactNumberTextBox";
            this.contactNumberTextBox.Size = new System.Drawing.Size(251, 20);
            this.contactNumberTextBox.TabIndex = 1;
            // 
            // zoneType1CheckBox
            // 
            this.zoneType1CheckBox.AutoSize = true;
            this.zoneType1CheckBox.Location = new System.Drawing.Point(43, 29);
            this.zoneType1CheckBox.Name = "zoneType1CheckBox";
            this.zoneType1CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType1CheckBox.TabIndex = 0;
            this.zoneType1CheckBox.Text = "checkBox1";
            this.zoneType1CheckBox.UseVisualStyleBackColor = true;
            // 
            // zoneType2CheckBox
            // 
            this.zoneType2CheckBox.AutoSize = true;
            this.zoneType2CheckBox.Location = new System.Drawing.Point(43, 52);
            this.zoneType2CheckBox.Name = "zoneType2CheckBox";
            this.zoneType2CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType2CheckBox.TabIndex = 0;
            this.zoneType2CheckBox.Text = "checkBox1";
            this.zoneType2CheckBox.UseVisualStyleBackColor = true;
            // 
            // zoneType3CheckBox
            // 
            this.zoneType3CheckBox.AutoSize = true;
            this.zoneType3CheckBox.Location = new System.Drawing.Point(43, 75);
            this.zoneType3CheckBox.Name = "zoneType3CheckBox";
            this.zoneType3CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType3CheckBox.TabIndex = 0;
            this.zoneType3CheckBox.Text = "checkBox1";
            this.zoneType3CheckBox.UseVisualStyleBackColor = true;
            // 
            // zoneType4CheckBox
            // 
            this.zoneType4CheckBox.AutoSize = true;
            this.zoneType4CheckBox.Location = new System.Drawing.Point(43, 98);
            this.zoneType4CheckBox.Name = "zoneType4CheckBox";
            this.zoneType4CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType4CheckBox.TabIndex = 0;
            this.zoneType4CheckBox.Text = "checkBox1";
            this.zoneType4CheckBox.UseVisualStyleBackColor = true;
            // 
            // zoneType5CheckBox
            // 
            this.zoneType5CheckBox.AutoSize = true;
            this.zoneType5CheckBox.Location = new System.Drawing.Point(43, 121);
            this.zoneType5CheckBox.Name = "zoneType5CheckBox";
            this.zoneType5CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType5CheckBox.TabIndex = 0;
            this.zoneType5CheckBox.Text = "checkBox1";
            this.zoneType5CheckBox.UseVisualStyleBackColor = true;
            // 
            // zoneType6CheckBox
            // 
            this.zoneType6CheckBox.AutoSize = true;
            this.zoneType6CheckBox.Location = new System.Drawing.Point(43, 144);
            this.zoneType6CheckBox.Name = "zoneType6CheckBox";
            this.zoneType6CheckBox.Size = new System.Drawing.Size(80, 17);
            this.zoneType6CheckBox.TabIndex = 0;
            this.zoneType6CheckBox.Text = "checkBox1";
            this.zoneType6CheckBox.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 357);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox contactNumberTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox visitorNameTextBox;
        private System.Windows.Forms.Label visitorNameLabel;
        private System.Windows.Forms.CheckBox zoneType6CheckBox;
        private System.Windows.Forms.CheckBox zoneType5CheckBox;
        private System.Windows.Forms.CheckBox zoneType4CheckBox;
        private System.Windows.Forms.CheckBox zoneType3CheckBox;
        private System.Windows.Forms.CheckBox zoneType2CheckBox;
        private System.Windows.Forms.CheckBox zoneType1CheckBox;

    }
}

